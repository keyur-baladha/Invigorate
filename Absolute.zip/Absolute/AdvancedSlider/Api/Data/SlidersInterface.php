<?php
namespace Absolute\AdvancedSlider\Api\Data;
interface SlidersInterface 
{
}